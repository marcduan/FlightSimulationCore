import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load the landing pad texture
image = cv2.imread("C:\\Users\\Duanm\\FlightSimulationCore\\ML_Predictions\\LandingPadPictures\\Figure4.jpg")

# Check if the image loaded correctly
if image is None:
    raise ValueError("Image not found or could not be loaded.")

# Step 1: Convert to grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Step 2: Apply GaussianBlur to soften
blurred = cv2.GaussianBlur(gray, (5, 5), 0)

# Step 3: Use edge detection to highlight markings
edges = cv2.Canny(blurred, 50, 150)

# Step 4: Overlay edges on the original texture
edges_colored = cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)  # Convert edges to BGR
enhanced_texture = cv2.addWeighted(image, 0.8, edges_colored, 0.2, 0)

# Save the enhanced texture
cv2.imwrite("enhanced_landing_pad.png", enhanced_texture)

# Display the result
plt.imshow(cv2.cvtColor(enhanced_texture, cv2.COLOR_BGR2RGB))
plt.title("Enhanced Landing Pad Texture")
plt.axis("off")
plt.show()
